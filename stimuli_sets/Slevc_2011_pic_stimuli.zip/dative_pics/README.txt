This collection includes 24 pictures designed to elicit dative sentences as well as other pictures used as filler or practice items in Slevc (2011). These pictures are made available under a Creative Commons Attribution-ShareAlike 4.0 International License  (CC-BY-SA 4.0:  http://creativecommons.org/licenses/by-sa/4.0/) - if you use them, please cite Slevc (2011) as the source:

Slevc. L.R. (2011). Saying what's on your mind: Working memory effects on sentence production. Journal of Experimental Psychology. Learning, Memory, and Cognition, 37(6), 1503-1514.
